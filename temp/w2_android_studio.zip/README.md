# w2 - Android Studio Project

This project was exported from APK Editor and can be imported into Android Studio.

## Import Instructions:

1. Extract this ZIP file to a folder on your computer
2. Open Android Studio
3. Click "File" > "Open" (or "Open an Existing Project")
4. Navigate to and select the extracted project folder (the one containing build.gradle)
5. Click "OK" to import
6. Wait for Gradle sync to complete
7. If prompted, download any missing SDK components

## Important Notes:

- Make sure you have Android SDK installed
- You may need to update the SDK versions in build.gradle to match your installed components
- Create a local.properties file with your SDK path if needed

## Project Structure:

- `app/src/main/AndroidManifest.xml` - Application manifest
- `app/src/main/res/` - Resources (layouts, drawables, values)
- `app/src/main/assets/` - Additional APK files

## Troubleshooting Common Gradle Errors:

### Multiple Task Action Failures:
If you encounter "Multiple task action failures occurred", try these solutions:

1. **Clean and Rebuild:**
   ```
   ./gradlew clean
   ./gradlew assembleDebug
   ```

2. **Invalidate Caches:**
   - In Android Studio: File > Invalidate Caches > Invalidate and Restart

3. **Update build.gradle versions:**
   - Update compileSdk to your installed SDK version
   - Update targetSdk to match compileSdk or lower

4. **Resource Issues:**
   - Check for duplicate resource names in different folders
   - Remove any corrupted XML files from res/ directories
   - Delete problematic drawable files

5. **AAPT Errors:**
   - The build.gradle already includes AAPT error handling
   - If issues persist, try disabling resource shrinking

### 9-Patch Errors:
- All .9.png files have been filtered out to prevent compilation errors
- If you need 9-patch drawables, create new ones using Android Studio's editor

### Resource Conflicts:
- Some resources may have conflicting definitions
- Check values/styles.xml and colors.xml for duplicate entries
- Remove or rename conflicting resources

### Memory Issues:
- If Gradle runs out of memory, add to gradle.properties:
  ```
  org.gradle.jvmargs=-Xmx4096m -Dfile.encoding=UTF-8
  ```

## Building:

1. Import the project into Android Studio
2. Sync the project with Gradle files
3. Clean and rebuild: `./gradlew clean assembleDebug`
4. If errors persist, check the "Build" tab for specific issues

## Source Code Recovery:

- This export contains only resources, not source code
- Use tools like jadx, dex2jar, or JADX-GUI for Java/Kotlin source recovery
- Decompiled source may need manual cleanup and debugging

## Additional Tips:

- Start with a minimal AndroidManifest.xml and add permissions as needed
- Test build frequently when adding back filtered resources
- Consider creating a new project and copying resources gradually if issues persist
